# Privacy Policy - Facebook Profile Checker

**Last Updated:** December 17, 2025

## Overview

Facebook Profile Checker ("the Extension") is committed to protecting your privacy. This policy explains what data we collect and how it is used.

## Data Collection

### What We Collect:
- **Profile verification decisions**: When you click "OK" or "Flag" on a profile, this decision is stored locally on your device only
- **No personal information**: We do not collect your name, email, or any personal data
- **No tracking**: We do not track your browsing activity

### What We DO NOT Collect:
- Your Facebook login credentials
- Your Facebook messages or posts
- Your browsing history
- Your personal information
- Analytics or usage data

## How Data is Stored

- **Local Storage Only**: All your flagging decisions are stored in your browser's local storage on your device
- **Not Transmitted**: Your data never leaves your computer
- **You Control It**: You can clear your data anytime by removing the extension

## Third-Party Services

The extension uses one external service:
- **Genderize.io**: Profile names are sent to this free API to estimate gender likelihood. No personal data is sent.

## Data Sharing

We do NOT:
- Sell your data
- Share your data with third parties
- Send your data to any servers
- Collect analytics

## User Rights

You have the right to:
- Delete all stored data by uninstalling the extension
- Use the extension without providing any personal information

## Changes to This Policy

We may update this privacy policy. Changes will be reflected with a new "Last Updated" date.

## Contact

For privacy questions, contact: yeayaa.com@gmail.com

---

By using this extension, you acknowledge that you have read and understood this privacy policy.
