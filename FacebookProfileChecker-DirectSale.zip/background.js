// Background Service Worker - Simple version (no AWS)

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // Manual flag management
  if (request.action === 'setManualFlag') {
    chrome.storage.local.get(['manualFlags'], (result) => {
      const flags = result.manualFlags || {};
      flags[request.profileKey] = { status: request.status, timestamp: Date.now() };
      chrome.storage.local.set({ manualFlags: flags }, () => sendResponse({ success: true }));
    });
    return true;
  }

  if (request.action === 'getManualFlag') {
    chrome.storage.local.get(['manualFlags'], (result) => {
      const flags = result.manualFlags || {};
      sendResponse({ flag: flags[request.profileKey] || null });
    });
    return true;
  }

  if (request.action === 'clearManualFlag') {
    chrome.storage.local.get(['manualFlags'], (result) => {
      const flags = result.manualFlags || {};
      delete flags[request.profileKey];
      chrome.storage.local.set({ manualFlags: flags }, () => sendResponse({ success: true }));
    });
    return true;
  }

  // Image analysis - returns null (manual verification mode)
  if (request.action === 'analyzeImage') {
    sendResponse({ gender: null, manualMode: true });
    return true;
  }
});

console.log('[Background] Facebook Profile Checker loaded');
