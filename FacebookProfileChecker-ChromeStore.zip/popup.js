// Popup script for Facebook Profile Checker

document.addEventListener('DOMContentLoaded', () => {
  const testButton = document.getElementById('testButton');
  const testStatus = document.getElementById('testStatus');
  const currentStatus = document.getElementById('currentStatus');

  // Check current page on load
  checkCurrentPageStatus();

  function checkCurrentPageStatus() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]?.url) {
        currentStatus.innerHTML = '<span class="status error">Cannot access tab</span>';
        return;
      }

      const url = tabs[0].url;
      if (!url.includes('facebook.com')) {
        currentStatus.innerHTML = '<span class="status error">Not on Facebook</span>';
        return;
      }

      // Check if profile page
      try {
        const urlObj = new URL(url);
        const excluded = ['/groups/', '/pages/', '/events/', '/marketplace/', '/watch/', '/messages/', '/notifications/', '/friends', '/photos', '/videos'];
        const isExcluded = excluded.some(p => url.includes(p));
        const isProfile = !isExcluded && (/^\/profile\.php/.test(urlObj.pathname) || /^\/[a-zA-Z0-9.]+\/?$/.test(urlObj.pathname));

        if (isProfile) {
          currentStatus.innerHTML = '<span class="status success">✓ Profile page detected</span>';
          triggerCheck(tabs[0].id);
        } else {
          currentStatus.innerHTML = '<span class="status error">Not a profile page</span>';
        }
      } catch {
        currentStatus.innerHTML = '<span class="status error">Invalid URL</span>';
      }
    });
  }

  function triggerCheck(tabId) {
    chrome.tabs.sendMessage(tabId, { action: 'forceCheck' }, () => {
      if (chrome.runtime.lastError) {
        chrome.scripting.executeScript({
          target: { tabId },
          files: ['content.js']
        }).catch(() => {});
      }
    });
  }

  // Force Check button
  testButton.addEventListener('click', () => {
    testButton.disabled = true;
    testButton.textContent = 'Checking...';
    
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]?.url?.includes('facebook.com')) {
        testButton.disabled = false;
        testButton.textContent = 'Force Check';
        showStatus(testStatus, 'Go to Facebook first', 'error');
        return;
      }
      
      chrome.tabs.sendMessage(tabs[0].id, { action: 'forceCheck' }, () => {
        testButton.disabled = false;
        testButton.textContent = 'Force Check';
        showStatus(testStatus, '✓ Check triggered', 'success');
      });
    });
  });

  function showStatus(el, msg, type) {
    el.textContent = msg;
    el.className = `status ${type}`;
    setTimeout(() => { el.textContent = ''; el.className = ''; }, 3000);
  }
});
