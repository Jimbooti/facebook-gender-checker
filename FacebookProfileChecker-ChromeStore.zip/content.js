// Facebook Gender Profile Checker - Content Script
// Detects gender mismatches between profile info and profile pictures
// Uses AI when available, falls back to human verification

class FacebookGenderChecker {
  constructor() {
    this.isProfilePage = false;
    this.profileData = null;
    this.state = 'idle';
    this.currentProfileKey = null;
    this.currentUrl = null;
    this.lastDetection = null;
    this.checkTimeout = null;
    this.analysisCache = {};
    this.init();
  }

  // ---------- Logging ----------
  logInfo(msg, extra) {
    console.log('[FB Gender Checker]', msg, extra || '');
  }
  logWarn(msg, extra) {
    console.warn('[FB Gender Checker]', msg, extra || '');
  }
  logError(msg, err) {
    console.error('[FB Gender Checker]', msg, err || '');
  }

  init() {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => this.startChecking());
    } else {
      this.startChecking();
    }
  }

  computeProfileKey(urlObj) {
    if (!urlObj) return null;
    if (urlObj.pathname === '/profile.php' && urlObj.searchParams.has('id')) {
      return `id:${urlObj.searchParams.get('id')}`;
    }
    if (urlObj.pathname.startsWith('/people/')) {
      const parts = urlObj.pathname.split('/').filter(Boolean);
      const maybeId = parts[parts.length - 1];
      if (/^\d+$/.test(maybeId)) return `people:${maybeId}`;
      return `people:${urlObj.pathname}`;
    }
    const firstSegment = urlObj.pathname.split('/').filter(Boolean)[0] || '';
    if (firstSegment && firstSegment !== 'profile.php') {
      return `user:${firstSegment.toLowerCase()}`;
    }
    return null;
  }

  detectProfilePagePure() {
    const url = window.location.href;
    let urlObj;
    try { urlObj = new URL(url); } catch { return { isProfilePage: false }; }

    const excludedPaths = [
      '/groups/', '/pages/', '/events/', '/marketplace/', '/watch/',
      '/login', '/signup', '/recover', '/help', '/about', '/privacy',
      '/settings', '/messages', '/notifications', '/bookmarks',
      '/games/', '/apps/', '/developers/', '/business/', '/ads/',
      '/stories/', '/reels/', '/video/', '/photo/', '/post/',
      '/p/', '/story/', '/permalink/', '/hashtag/', '/search/',
      '/home', '/feed', '/newsfeed'
    ];
    const path = urlObj.pathname + urlObj.search;
    if (excludedPaths.some(p => path.includes(p))) {
      return { isProfilePage: false };
    }

    const baseProfilePatterns = [
      /^\/profile\.php$/,
      /^\/[a-zA-Z0-9.]+\/?$/,
      /^\/people\/[^/]+\/\d+\/?/
    ];
    const isProfileUrl = baseProfilePatterns.some(re => re.test(urlObj.pathname)) ||
      (urlObj.pathname === '/profile.php' && urlObj.searchParams.has('id'));

    return {
      isProfilePage: isProfileUrl,
      profileKey: isProfileUrl ? this.computeProfileKey(urlObj) : null
    };
  }

  async startChecking() {
    if (this.state === 'analyzing') return;

    const detection = this.detectProfilePagePure();
    this.currentProfileKey = detection.profileKey;
    this.currentUrl = window.location.href;

    if (!detection.isProfilePage) {
      this.logInfo('Not a profile page');
      return;
    }

    // Check for existing manual flag
    const manualFlag = await this.getManualFlag(this.currentProfileKey);
    if (manualFlag) {
      this.logInfo('Using stored manual flag', manualFlag);
      this.showVerificationBadge({
        profileGender: null,
        pictureUrl: null,
        manualStatus: manualFlag.status
      });
      return;
    }

    this.state = 'analyzing';
    this.logInfo('Profile page detected, analyzing...', { profileKey: this.currentProfileKey });

    await this.extractAndAnalyze();
  }

  async extractAndAnalyze() {
    // Extract profile name
    const nameSelectors = [
      'h1[data-testid="user-name"]',
      'h1[dir="auto"]',
      '[data-pagelet="ProfileTilesFeed"] h1',
      'div[role="main"] h1'
    ];
    let name = null;
    for (const sel of nameSelectors) {
      const el = document.querySelector(sel);
      if (el) { name = el.textContent.trim(); break; }
    }
    if (!name) {
      const ogTitle = document.querySelector('meta[property="og:title"]');
      if (ogTitle) name = ogTitle.content;
    }

    // Infer gender from name
    let profileGender = null;
    if (name) {
      profileGender = await this.inferGenderFromName(name);
    }

    // Extract profile picture URL - collect multiple candidates
    let pictureUrl = null;
    const candidates = [];
    
    // Helper to check if URL is likely a placeholder/default avatar
    const isPlaceholder = (url) => {
      if (!url) return true;
      // Facebook default avatar patterns
      if (url.includes('static.xx.fbcdn.net')) return true;
      if (url.includes('default_avatar')) return true;
      if (url.includes('silhouette')) return true;
      if (url.includes('placeholder')) return true;
      // Don't filter small images - they might have faces
      return false;
    };
    
    // 1. Try og:image (usually high quality)
    const ogImage = document.querySelector('meta[property="og:image"]');
    if (ogImage?.content && !isPlaceholder(ogImage.content)) {
      candidates.push({ url: ogImage.content, priority: 1, source: 'og:image' });
    }
    
    // 2. Profile picture with data attribute
    const profilePic = document.querySelector('img[data-imgperflogname="profilePicture"]');
    if (profilePic?.src && !isPlaceholder(profilePic.src)) {
      candidates.push({ url: profilePic.src, priority: 2, source: 'data-imgperflogname' });
    }
    
    // 3. SVG image inside profile photo link (Facebook's new structure)
    const svgProfileImg = document.querySelector('a[href*="/photo"] image, svg image[href*="fbcdn"]');
    if (svgProfileImg) {
      const href = svgProfileImg.getAttribute('xlink:href') || svgProfileImg.getAttribute('href');
      if (href && !isPlaceholder(href)) {
        candidates.push({ url: href, priority: 2, source: 'svg-image' });
      }
    }
    
    // 4. Small circular profile avatar (often in header or intro section)
    const circularAvatars = document.querySelectorAll([
      'svg[role="img"] image[href*="fbcdn"]',
      'svg image[xlink\\:href*="fbcdn"]',
      'a[aria-label*="profile picture" i] img',
      'div[aria-label*="profile picture" i] img',
      'image[preserveAspectRatio="xMidYMid slice"]'
    ].join(', '));
    circularAvatars.forEach((el, i) => {
      const url = el.getAttribute('xlink:href') || el.getAttribute('href') || el.src;
      if (url && !isPlaceholder(url)) {
        candidates.push({ url, priority: 2.5 + (i * 0.1), source: 'circular-avatar' });
      }
    });
    
    // 5. Main profile area images
    const mainImages = document.querySelectorAll('[role="main"] img[src*="scontent"][src*="fbcdn"]');
    mainImages.forEach((img, i) => {
      if (img.src && !isPlaceholder(img.src)) {
        candidates.push({ url: img.src, priority: 3 + (i * 0.1), source: 'main-img' });
      }
    });
    
    // 6. Any image with profile picture alt text
    const altProfilePics = document.querySelectorAll('img[alt*="profile picture" i]');
    altProfilePics.forEach((img, i) => {
      if (img.src && !isPlaceholder(img.src)) {
        candidates.push({ url: img.src, priority: 4 + (i * 0.1), source: 'alt-text' });
      }
    });
    
    // 7. ANY fbcdn image on the page (last resort) - sorted by size
    const allFbImages = document.querySelectorAll('img[src*="fbcdn"]');
    allFbImages.forEach((img, i) => {
      if (img.src && !isPlaceholder(img.src)) {
        // Skip tiny images (less than 50px)
        const w = img.naturalWidth || img.width || 0;
        const h = img.naturalHeight || img.height || 0;
        if (w >= 50 && h >= 50) {
          candidates.push({ url: img.src, priority: 5 + (i * 0.01), source: 'any-fbcdn' });
        }
      }
    });
    
    // 8. Cover photo as fallback (might have face)
    const coverPhoto = document.querySelector('img[data-imgperflogname="coverPhoto"]');
    if (coverPhoto?.src && !isPlaceholder(coverPhoto.src)) {
      candidates.push({ url: coverPhoto.src, priority: 10, source: 'cover' });
    }
    
    // Remove duplicates by URL
    const seen = new Set();
    const uniqueCandidates = candidates.filter(c => {
      const key = c.url.split('?')[0]; // Compare without query params
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
    
    this.logInfo('Image candidates found', uniqueCandidates.map(c => ({ source: c.source, url: c.url.substring(0, 80) })));
    
    // Sort by priority
    uniqueCandidates.sort((a, b) => a.priority - b.priority);
    
    // Helper to clean FB image URL for larger version
    const cleanFbUrl = (url) => {
      if (url && url.includes('fbcdn')) {
        return url
          .replace(/\/[sp]\d+x\d+\//, '/')
          .replace(/&width=\d+/, '')
          .replace(/&height=\d+/, '')
          .replace(/\?width=\d+/, '?')
          .replace(/\?height=\d+/, '?');
      }
      return url;
    };

    // Get the best profile picture URL (first valid candidate)
    let usedPictureUrl = null;
    if (uniqueCandidates.length > 0) {
      usedPictureUrl = cleanFbUrl(uniqueCandidates[0].url);
    }
    
    // Check if AWS is configured
    let pictureGender = null;
    let awsStatus = 'optional'; // AWS is optional by default
    
    const hasAwsKeys = await this.checkAwsConfigured();
    
    if (hasAwsKeys && usedPictureUrl) {
      // AWS is configured - try to analyze images
      awsStatus = 'analyzing';
      
      for (let i = 0; i < Math.min(uniqueCandidates.length, 5); i++) {
        const candidate = uniqueCandidates[i];
        const cleanedUrl = cleanFbUrl(candidate.url);
        
        this.logInfo(`Trying image candidate ${i + 1}/${uniqueCandidates.length}`, { 
          source: candidate.source, 
          url: cleanedUrl.substring(0, 100) 
        });
        
        const result = await this.analyzeProfilePicture(cleanedUrl);
        this.logInfo(`Candidate ${i + 1} result`, { 
          gender: result.gender, 
          status: result.status,
          source: candidate.source
        });
        
        // If we got a gender, use this image
        if (result.gender) {
          pictureGender = result.gender;
          awsStatus = result.status;
          usedPictureUrl = cleanedUrl;
          this.logInfo('Found face in image', { source: candidate.source, gender: pictureGender });
          break;
        }
        
        // If no face, try next candidate
        if (result.status === 'no_face') {
          awsStatus = 'no_face';
          usedPictureUrl = cleanedUrl;
        }
      }
    } else if (!hasAwsKeys) {
      // AWS not configured - that's fine, manual verification mode
      this.logInfo('AWS not configured - using manual verification mode');
      awsStatus = 'optional';
    } else {
      awsStatus = 'no_image';
    }
    
    pictureUrl = usedPictureUrl;
    this.logInfo('Final image selection', { pictureUrl, pictureGender, awsStatus });

    this.profileData = { name, profileGender, pictureUrl };
    this.logInfo('Profile data extracted', this.profileData);

    // Decision logic
    const profileG = (profileGender || '').toLowerCase();
    const pictureG = (pictureGender || '').toLowerCase();

    // Priority case: male profile + female picture = auto-flag (catfish)
    if (profileG === 'male' && pictureG === 'female') {
      this.logWarn('AUTO-FLAGGED: Male profile with female picture');
      this.showVerificationBadge({
        profileGender: profileG,
        pictureGender: pictureG,
        pictureUrl,
        awsStatus,
        autoFlagged: true
      });
      this.state = 'done';
      return;
    }

    // If AI could confirm a match, auto-verify
    if (profileG && pictureG && profileG === pictureG) {
      this.showVerificationBadge({
        profileGender: profileG,
        pictureGender: pictureG,
        pictureUrl,
        awsStatus,
        verified: true
      });
      this.state = 'done';
      return;
    }

    // Profile gender unknown but AWS detected picture gender = no evidence of mismatch
    // Auto-verify since we can't prove any catfishing
    if (!profileG && pictureG) {
      this.logInfo('Profile gender unknown, but picture detected - auto-verifying');
      this.showVerificationBadge({
        profileGender: 'unknown',
        pictureGender: pictureG,
        pictureUrl,
        awsStatus,
        verified: true,
        verifyReason: 'Picture detected, no name mismatch'
      });
      this.state = 'done';
      return;
    }

    // Profile gender known but picture unknown = needs manual check
    // Or both unknown = needs manual check
    this.showVerificationBadge({
      profileGender: profileG || 'unknown',
      pictureGender: pictureG || null,
      pictureUrl,
      awsStatus,
      needsVerification: true
    });
    this.state = 'done';
  }

  async inferGenderFromName(name) {
    try {
      const firstName = name.split(' ')[0];
      const response = await fetch(`https://api.genderize.io?name=${encodeURIComponent(firstName)}`);
      const data = await response.json();
      if (data.gender && data.probability > 0.6) {
        return data.gender;
      }
    } catch (e) {
      this.logWarn('Genderize API failed', e);
    }
    return null;
  }

  async checkAwsConfigured() {
    return new Promise((resolve) => {
      try {
        chrome.storage.sync.get(['awsAccessKeyId', 'awsSecretAccessKey'], (result) => {
          resolve(!!(result.awsAccessKeyId && result.awsSecretAccessKey));
        });
      } catch {
        resolve(false);
      }
    });
  }

  async analyzeProfilePicture(imageUrl) {
    try {
      return new Promise((resolve) => {
        const timeout = setTimeout(() => resolve({ gender: null, status: 'timeout' }), 20000);
        chrome.runtime.sendMessage({ action: 'analyzeImage', imageUrl }, (response) => {
          clearTimeout(timeout);
          this.logInfo('Raw AWS response', response);
          
          if (chrome.runtime.lastError) {
            this.logError('Chrome runtime error', chrome.runtime.lastError);
            resolve({ gender: null, status: 'error' });
            return;
          }
          if (response?.gender) {
            const status = response.lowConfidence ? 'low_confidence' : 'success';
            resolve({ gender: response.gender, status });
          } else if (response?.noCredentials) {
            resolve({ gender: null, status: 'not_configured' });
          } else if (response?.noFace) {
            resolve({ gender: null, status: 'no_face' });
          } else {
            resolve({ gender: null, status: 'unknown_error' });
          }
        });
      });
    } catch (e) {
      this.logError('analyzeProfilePicture exception', e);
      return { gender: null, status: 'error' };
    }
  }

  async getManualFlag(profileKey) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ action: 'getManualFlag', profileKey }, (response) => {
          if (chrome.runtime.lastError) {
            resolve(null);
            return;
          }
          resolve(response?.flag || null);
        });
      } catch {
        resolve(null);
      }
    });
  }

  async setManualFlag(profileKey, status) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ action: 'setManualFlag', profileKey, status }, () => {
          resolve();
        });
      } catch {
        resolve();
      }
    });
  }

  async clearManualFlag(profileKey) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ action: 'clearManualFlag', profileKey }, () => {
          resolve();
        });
      } catch {
        resolve();
      }
    });
  }

  showVerificationBadge(data) {
    // Remove existing
    const existing = document.getElementById('fb-gender-checker-badge');
    if (existing) existing.remove();

    const badge = document.createElement('div');
    badge.id = 'fb-gender-checker-badge';
    badge.className = 'fb-gender-badge';

    let bgColor = '#1877f2'; // blue default
    let icon = '🔍';
    let title = 'Verify Profile';
    let showButtons = true;

    let showReset = false;

    if (data.manualStatus === 'flagged') {
      bgColor = '#d32f2f';
      icon = '⚠️';
      title = 'FLAGGED';
      showButtons = false;
      showReset = true;
    } else if (data.autoFlagged) {
      bgColor = '#d32f2f';
      icon = '⚠️';
      title = 'AUTO-FLAGGED';
      showButtons = false;
    } else if (data.manualStatus === 'ok') {
      bgColor = '#388e3c';
      icon = '✓';
      title = 'Verified OK';
      showButtons = false;
      showReset = true;
    } else if (data.verified) {
      bgColor = '#388e3c';
      icon = '✓';
      // Show specific message if profile was unknown
      if (data.profileGender === 'unknown' && data.pictureGender) {
        title = `Picture: ${data.pictureGender.toUpperCase()}`;
      } else {
        title = 'Verified OK';
      }
      showButtons = false;
    } else if (data.profileGender === 'male') {
      bgColor = '#f57c00'; // orange - priority
      icon = '👤';
      title = 'Male Profile - Verify Picture';
    }

    badge.style.cssText = `
      position: fixed !important;
      top: 10px !important;
      right: 10px !important;
      z-index: 2147483647 !important;
      background: ${bgColor} !important;
      color: white !important;
      padding: 15px !important;
      border-radius: 12px !important;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
      font-size: 14px !important;
      box-shadow: 0 4px 20px rgba(0,0,0,0.3) !important;
      max-width: 300px !important;
      min-width: 250px !important;
    `;

    // Header
    const header = document.createElement('div');
    header.style.cssText = 'display: flex; align-items: center; margin-bottom: 12px; font-weight: bold; font-size: 15px;';
    header.innerHTML = `<span style="margin-right: 8px; font-size: 20px;">${icon}</span>${title}`;
    badge.appendChild(header);

    // Show detected picture gender if available (from AI)
    if (data.pictureGender && !data.manualStatus) {
      const picGenderRow = document.createElement('div');
      picGenderRow.style.cssText = 'margin-bottom: 8px; font-size: 12px; padding: 4px 8px; border-radius: 4px; background: rgba(0,0,0,0.2);';
      picGenderRow.innerHTML = `Picture appears: <strong>${data.pictureGender.toUpperCase()}</strong>`;
      badge.appendChild(picGenderRow);
    }

    // Profile info
    if (data.profileGender) {
      const genderRow = document.createElement('div');
      genderRow.style.cssText = 'margin-bottom: 8px; font-size: 13px;';
      genderRow.innerHTML = `<strong>Profile Gender:</strong> ${data.profileGender.toUpperCase()}`;
      badge.appendChild(genderRow);
    }

    // Picture thumbnail
    if (data.pictureUrl) {
      const picContainer = document.createElement('div');
      picContainer.style.cssText = 'margin: 10px 0; text-align: center;';
      
      const pic = document.createElement('img');
      pic.src = data.pictureUrl;
      pic.style.cssText = 'width: 80px; height: 80px; border-radius: 50%; border: 3px solid white; object-fit: cover;';
      picContainer.appendChild(pic);

      // Note: pictureGender already shown in AWS status row above

      badge.appendChild(picContainer);
    }

    // Buttons for verification
    if (showButtons) {
      const buttonRow = document.createElement('div');
      buttonRow.style.cssText = 'display: flex; gap: 10px; margin-top: 12px;';

      const okBtn = document.createElement('button');
      okBtn.textContent = '✓ Looks OK';
      okBtn.style.cssText = `
        flex: 1;
        padding: 10px;
        border: none;
        border-radius: 6px;
        font-weight: bold;
        cursor: pointer;
        background: #388e3c;
        color: white;
        font-size: 13px;
      `;
      okBtn.addEventListener('click', async () => {
        await this.setManualFlag(this.currentProfileKey, 'ok');
        this.showVerificationBadge({ ...data, manualStatus: 'ok' });
      });

      const flagBtn = document.createElement('button');
      flagBtn.textContent = '⚠ Flag';
      flagBtn.style.cssText = `
        flex: 1;
        padding: 10px;
        border: none;
        border-radius: 6px;
        font-weight: bold;
        cursor: pointer;
        background: #d32f2f;
        color: white;
        font-size: 13px;
      `;
      flagBtn.addEventListener('click', async () => {
        await this.setManualFlag(this.currentProfileKey, 'flagged');
        this.showVerificationBadge({ ...data, manualStatus: 'flagged' });
      });

      buttonRow.appendChild(okBtn);
      buttonRow.appendChild(flagBtn);
      badge.appendChild(buttonRow);
    }

    // Reset button (for manual flags only)
    if (showReset) {
      const resetBtn = document.createElement('button');
      resetBtn.textContent = '↺ Reset';
      resetBtn.style.cssText = `
        width: 100%;
        margin-top: 10px;
        padding: 8px;
        border: none;
        border-radius: 6px;
        font-size: 12px;
        cursor: pointer;
        background: rgba(255,255,255,0.2);
        color: white;
      `;
      resetBtn.addEventListener('click', async () => {
        await this.clearManualFlag(this.currentProfileKey);
        this.state = 'idle';
        this.startChecking();
      });
      badge.appendChild(resetBtn);
    }

    // Close button
    const closeBtn = document.createElement('button');
    closeBtn.textContent = '×';
    closeBtn.style.cssText = `
      position: absolute;
      top: 5px;
      right: 8px;
      background: none;
      border: none;
      color: white;
      font-size: 20px;
      cursor: pointer;
      opacity: 0.7;
    `;
    closeBtn.addEventListener('click', () => badge.remove());
    badge.appendChild(closeBtn);

    document.body.appendChild(badge);
    this.logInfo('Verification badge shown');
  }
}

// Initialize
let checker = null;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'forceCheck') {
    if (!checker) checker = new FacebookGenderChecker();
    checker.state = 'idle';
    checker.analysisCache = {};
    checker.startChecking();
    sendResponse({ success: true });
    return true;
  }
});

window.addEventListener('fbGenderCheckerForceCheck', () => {
  if (!checker) checker = new FacebookGenderChecker();
  checker.state = 'idle';
  checker.startChecking();
});

const observer = new MutationObserver(() => {
  if (!checker) {
    checker = new FacebookGenderChecker();
  } else {
    clearTimeout(checker.checkTimeout);
    checker.checkTimeout = setTimeout(() => {
      // Only re-check if URL changed
      if (checker.currentUrl !== window.location.href) {
        checker.state = 'idle';
        checker.startChecking();
      }
    }, 2000);
  }
});

if (document.body) {
  observer.observe(document.body, { childList: true, subtree: true });
  checker = new FacebookGenderChecker();
} else {
  const bodyObserver = new MutationObserver((mutations, obs) => {
    if (document.body) {
      obs.disconnect();
      observer.observe(document.body, { childList: true, subtree: true });
      checker = new FacebookGenderChecker();
    }
  });
  bodyObserver.observe(document.documentElement, { childList: true, subtree: true });
}
